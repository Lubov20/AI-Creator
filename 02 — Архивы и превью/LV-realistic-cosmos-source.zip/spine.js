import * as THREE from 'three';

// Grayscale anatomical image on a shallow relief surface: no chrome or repeated mechanical components.
export async function createSpine(){
 const group=new THREE.Group(),texture=await new THREE.TextureLoader().loadAsync('./assets/spine-mri-source.png');texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=4;
 const material=new THREE.ShaderMaterial({uniforms:{image:{value:texture}},transparent:true,depthWrite:false,side:THREE.DoubleSide,
 vertexShader:'uniform sampler2D image;varying vec2 vUv;void main(){vUv=uv;vec3 p=position;vec4 t=texture2D(image,uv);float gray=dot(t.rgb,vec3(.299,.587,.114));p.z+=(gray-.3)*.26*t.a;p.x+=sin(p.y*.18)*.035*t.a;gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.);}',
 fragmentShader:'uniform sampler2D image;varying vec2 vUv;void main(){vec4 tex=texture2D(image,vUv);float alpha=smoothstep(.05,.58,tex.a);if(alpha<.012)discard;float gray=dot(tex.rgb,vec3(.299,.587,.114));gray=mix(gray,sqrt(max(gray,0.)),.1);gl_FragColor=vec4(vec3(gray),alpha*.94);\n#include <colorspace_fragment>\n}'});
 const mesh=new THREE.Mesh(new THREE.PlaneGeometry(20*1024/1536,20,130,240),material);mesh.position.set(0,14,.4);group.add(mesh);return group;
}

export function createGlitter(renderer){
 const count=innerWidth<600?11000:22000,positions=new Float32Array(count*3),colors=new Float32Array(count*3),sizes=new Float32Array(count),seeds=new Float32Array(count),layers=new Float32Array(count);const color=new THREE.Color();
 for(let i=0;i<count;i++){positions.set([Math.random()*2-1,Math.random()*2-1,0],i*3);const rank=Math.random(),white=Math.random()<.16;layers[i]=Math.random();seeds[i]=Math.random();sizes[i]=rank<.64?.7+Math.random()*1.0:rank<.93?1.9+Math.random()*2.6:rank<.995?4.8+Math.random()*5:12+Math.random()*10;color.setHSL(white?.88:.87+Math.random()*.075,white?.08:.72+Math.random()*.26,white?.88:.5+Math.random()*.22);colors.set([color.r,color.g,color.b],i*3)}
 const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.BufferAttribute(positions,3));geometry.setAttribute('color',new THREE.BufferAttribute(colors,3));geometry.setAttribute('size',new THREE.BufferAttribute(sizes,1));geometry.setAttribute('seed',new THREE.BufferAttribute(seeds,1));geometry.setAttribute('layer',new THREE.BufferAttribute(layers,1));
 const uniforms={time:{value:0},reveal:{value:1},pixel:{value:renderer.getPixelRatio()},flow:{value:null},pointer:{value:new THREE.Vector2(.5,.5)},aspect:{value:1},motion:{value:0}};
 const material=new THREE.ShaderMaterial({uniforms,transparent:true,depthWrite:false,depthTest:false,blending:THREE.AdditiveBlending,
 vertexShader:'uniform float time,pixel,aspect,motion;uniform sampler2D flow;uniform vec2 pointer;attribute vec3 color;attribute float size,seed,layer;varying vec3 vColor;varying float vAlpha,vGlint,vSize,vSeed;void main(){vColor=color;vSize=size;vSeed=seed;vec2 p=position.xy;float depth=.25+layer*.75;p.y=mod(p.y+1.+cameraPosition.y*.004*depth+time*.0015*depth,2.)-1.;p.x+=sin(time*.035+seed*20.)*.002;vec2 screen=p*.5+.5;vec2 d=(screen-pointer)*vec2(aspect,1.);vec2 direction=normalize(d+vec2(.0001));float repel=(1.-smoothstep(.009,.135,length(d)))*.10*motion;vec2 wake=(texture2D(flow,clamp(screen,.001,.999)).rg*2.-1.)*.10;p+=(direction/vec2(aspect,1.)*repel+wake)*2.;gl_Position=vec4(p,0.,1.);float flicker=.5+.5*sin(time*(.32+seed*1.5)+seed*100.);vGlint=pow(flicker,10.+seed*28.);gl_PointSize=max(.65,size*pixel*(.65+depth*.45)*(1.+vGlint*.5));vAlpha=size<1.5?(.24+.48*flicker):size<4.0?(.48+.55*flicker):(.24+.95*vGlint);}',
 fragmentShader:'varying vec3 vColor;varying float vAlpha,vGlint,vSize,vSeed;void main(){vec2 p=gl_PointCoord-.5;float r=length(p);if(r>.5)discard;float core=exp(-r*r*90.);float halo=exp(-r*r*15.)*.2;float arms=(exp(-abs(p.x)*70.)+exp(-abs(p.y)*70.))*exp(-r*5.);float disk=1.-smoothstep(.15,.45,r);float shape=vSize<1.5?disk:vSize<4.?core+halo:core+halo+arms*(.18+vGlint*.7);vec3 c=vColor*(1.1+vGlint*1.2)+vec3(1.,.65,.9)*core*vGlint*.5;gl_FragColor=vec4(c,shape*vAlpha);\n#include <colorspace_fragment>\n}'});
 const stars=new THREE.Points(geometry,material);stars.frustumCulled=false;stars.renderOrder=3;return stars;
}

